SciX crack to download directly from scihub domains

1. Copy 'exthread.dll' from any of the domains folder,
2. Go to SciX installed path,
3. Replace the existing exthread.dll with copied one.
4. Voila! You can now input url,doi or any other method you use with scihub in the input box and click download. The article will be downloaded from scihub.

Note: You can use SciX's browser extension too